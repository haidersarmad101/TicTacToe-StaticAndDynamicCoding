
#include <stdio.h>
#include <iostream>
#include <cstdlib>
using namespace std;
#define GREEN   "\033[32m" 

string B[10] = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

void clear_screen() {
#ifdef _WIN32
	system("cls");
#else
	system("clear");
#endif
}

int checkWin() {
	for (int i = 0, j = 0; i < 3; i++, j += 3)
		if (B[i + 1] == B[i + 4] && B[i + 4] == B[i + 7] || B[j + 1] == B[j + 2] && B[j + 2] == B[j + 3])
			return 1;
	if (B[1] == B[5] && B[5] == B[9] || B[3] == B[5] && B[5] == B[7])
		return 1;
	for (int i = 1; i <= 9; i++)
		if (B[i] == string(1, '0' + i)) return -1;
	return 0;
}

void displayBoard() {
	clear_screen();
	cout << "\n\n\tTic Tac Toe\n\n\033[32mPlayer 1 (X)\033[0m  -  \033[35mPlayer 2 (O)\n\n\033[0m";
	cout << "    _________________\n";
	for (int i = 0; i < 9; i += 3) {
		cout << "   |     |     |     |\n";
		cout << "   |  " << B[i + 1] << "  |  " << B[i + 2] << "  |  " << B[i + 3] << "  |\n";
		cout << "   |_____|_____|_____|\n";
	}
	cout << "\n\n";
}


void instr_exec_start_to_end()
{

}

int main()
{
	int next = 0;
	double seconds = 0;
	time_t timer1, timer2;
	time_t timerStart, timerEnd;
	time(&timerStart);
	printf("This is the start of our instrumentation phase \n");
	printf("Instrumentation Level1(Program):Started\n");
	printf("Instrumentation Level2(Program_Initialization):Started\n");
	cin.get();

	
	
	int player = 1, x=0, choice=0;
	string color[] = { "\033[32m", "\033[35m" };
	string mark;

	time(&timer2);  /* get current time  later */
	seconds = difftime(timer2, timerStart);
	printf("Instrumentation Level2(Program_intialization):Ended with time elapsed:%f mili seconds\n", (seconds * 1000));
	time(&timer1);
	cin.get();
	printf("Instrumentation Level3(Program_mainExecutionLoop):Started\n");
	cin.get();
	do {
		displayBoard();
		player = 1 - player;
		cout << color[player] << "Player " << player + 1 << ": \033[0m";
		cin >> choice;
		mark = player ? "\033[35mO\033[0m" : "\033[32mX\033[0m";
		if (B[choice] == string(1, '0' + choice))
			B[choice] = mark;
		else {
			cout << "Invalid move ";
			player = 1 - player;
			cin.ignore();
			cin.get();
			continue;
		}
		time_t cwtime1, cwtime2;
		time(&cwtime1);
		printf("Instrumentation Level4(Program_checkWinFunction):Started\n");
		cin.get();
		x = checkWin();
		time(&cwtime2);  /* get current time  later */
		seconds = difftime(cwtime2, cwtime1);
		printf("Instrumentation Level4(Program_checkWinFunction):Ended with time elapsed:%f mili seconds\n", (seconds *1000));
		cin.get();
	} while (x == -1);

	time(&timer2);  /* get current time  later */
	seconds = difftime(timer2, timer1);
	printf("Instrumentation Level3(Program_mainExecutionLoop):Ended with time elapsed:%f mili seconds\n", (seconds * 1000));
	cin.get();

	
	printf("Instrumentation Level5(Program_displayBoard):Started\n");
	cin.get();
	time_t dB1, dB2;
	time(&dB1);

	displayBoard();
	time(&dB2);  /* get current time  later */
	seconds = difftime(dB2, dB1);
	printf("Instrumentation Level5(Program_displayBoard):Ended with time elapsed:%f mili seconds\n", (seconds * 1000));
	cin.get();
	x ? cout << color[player] << "Player " << player + 1 << "\033[0m" << " wins! " : cout << "Draw";
	cin.ignore();
	cin.get();
	time(&timerEnd);  /* get current time  later */
	seconds = difftime(timerEnd, timerStart);
	printf("Instrumentation Level1(Program):Ended with time elapsed:%f mili seconds\n",(seconds*1000));
	cin.get();
	return 0;
}
